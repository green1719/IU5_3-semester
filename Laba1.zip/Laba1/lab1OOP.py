import math
class Solution:

    def __init__(self, a, b, c):
        if a == 0:
            raise ValueError("Страший коэфициент не может быть равен 0")
        self.a = a
        self.b = b
        self.c = c

    def solution(self):
        if isinstance(self.a, int) and isinstance(self.b, int) and isinstance(self.c, int):
            discriminant = self.b ** 2 - 4 * self.a * self.c
            if discriminant > 0:
                x1 = (-self.b + math.sqrt(discriminant)) / (2 * self.a)
                x2 = (-self.b - math.sqrt(discriminant)) / (2 * self.a)
                self.answer = f"Ваши корни: {x1}, {x2}"
            elif discriminant == 0:
                x = -self.b / (2 * self.a)
                self.answer = f"Ваш корень: {x}"
            else:
                self.answer = "Поздравляю, корней нет"

    def get_balance(self):
        return self.answer

def display_menu():
    print("\nСписок задач")
    print("1. ВВести A, B, C и посчитать ответ")
    print("2. Выход")

while True:
    display_menu()
    choice = input("Выберите действие (1-2): ")
    if choice == "1":
        try:
            print("Введите три коэффициента A, B, C через пробел:")
            a, b, c = map(int, input().split())
            equation = Solution(a, b, c)
            equation.solution()
            print(equation.get_balance())
        except ValueError:
            print("Ошибка: введите три целых числа")

    elif choice == "2":
        print("Выход из программы.")
        break
    else:
        print("Неверный выбор, попробуйте снова.")