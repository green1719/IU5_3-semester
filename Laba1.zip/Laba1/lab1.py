import math

def solution(a, b, c):
    if isinstance(a, int) and isinstance(b, int) and isinstance(c, int):
        discriminant = b**2 - 4*a*c
        if discriminant > 0:
            x1 = (-b + math.sqrt(discriminant)) / (2*a)
            x2 = (-b - math.sqrt(discriminant)) / (2*a)
            print(f"Ваши корни: {x1}, {x2}")
        elif discriminant == 0:
            x = -b / (2*a)
            print(f"Ваш корень: {x}")
        else:
            print("Поздравляю, корней нет")

def display_menu():
    print("\nСписок задач")
    print("1. ВВести A, B, C и посчитать ответ")
    print("2. Выход")

while True:
    display_menu()
    choice = input("Выберите действие (1-2): ")
    if choice == "1":
        try:
            print("Введите три коэффициента A, B, C через пробел:")
            a, b, c = map(int, input().split())
            solution(a, b, c)
        except ValueError:
            print("Ошибка: введите три целых числа")
        except ZeroDivisionError:
            print("Ошибка: коэффициент 'a' не может быть нулем")
    elif choice == "2":
        print("Выход из программы.")
        break
    else:
        print("Неверный выбор, попробуйте снова.")