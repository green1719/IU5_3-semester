use std::io;
// use std::num::Float;
fn solution(a: f32, b:f32, c:f32){
    let discriminant: f32 = b.powi(2) - 4.0*a*c;
    if discriminant > 0.0{
            let x1 = (-b + discriminant.sqrt()) / (2.0*a);
            let x2 = (-b - discriminant.sqrt()) / (2.0*a);
            println!("Ваши корни: {}, {}", x1, x2);
        }
        else if discriminant == 0.0{
            let x = -b / (2.0*a);
            println!("Ваш корень: {}", x);
        }
        else{
            println!("Поздравляю, корней нет");
        }
}

fn display_menu(){
    println!("Список задач");
    println!("1. ВВести A, B, C и посчитать ответ");
    println!("2. Выход");
}
fn parse_float(s: &str) -> f32{
    s.parse().expect("Ошибка парсинга числа")
}

fn main(){
    loop {
    display_menu();
    println!("Выберите действие (1-2): ");
    let mut choice = String::new();
    io::stdin().read_line(&mut choice).expect("Ошибка чтения строки");
    if choice.trim() == "1"{
        let mut coefficients = String::new();
        println!("Введите три коэффициента A, B, C через пробел:");
        io::stdin().read_line(&mut coefficients).expect("Ошибка чтения строки");
        let parts: Vec<&str> = coefficients.trim().split_whitespace().collect();
        if parts.len() != 3 {
            println!("Ошибка: введите ровно три числа");
            continue;
        }

        let a = parse_float(parts[0]);
        let b = parse_float(parts[1]); 
        let c = parse_float(parts[2]);

        if a == 0.0 {
            println!("Ошибка: коэффициент 'a' не может быть нулем");
        } else {
            solution(a, b, c);
        }
    }    
    else if choice.trim() == "2"{
        println!("Выход из программы.");
        break;}
    else{
        println!("Неверный выбор, попробуйте снова.");}
    }
}
