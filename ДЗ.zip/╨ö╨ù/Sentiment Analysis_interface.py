import json
import re
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import load_model

model_filename = "models/sentiment_lstm.h5"
meta_filename = "models/sentiment_meta.json"

print(f"Загружаю модель из '{model_filename}' ...")
model = load_model(model_filename)

# Повторная компиляция и добавление AUC
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy', tf.keras.metrics.AUC(name="auc")])

print(f"Загружаю метаданные из '{meta_filename}' ...")
with open(meta_filename, "r", encoding="utf-8") as f:
    meta = json.load(f)

num_words = int(meta["num_words"])
max_len = int(meta["max_len"])
word_index = meta["word_index"]

def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-zA-Z']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def encode_text(text: str):
    tokens = clean_text(text).split()
    encoded = [1] # START token
    for w in tokens:
        raw_idx = word_index.get(w)
        if raw_idx is None:
            encoded.append(2) # UNK
        else:
            idx = raw_idx + 3
            if idx >= num_words:
                encoded.append(2) # UNK
            else:
                encoded.append(idx)
    return pad_sequences([encoded], maxlen=max_len)

def analyze_text(text: str):
    encoded = encode_text(text)
    pred = float(model.predict(encoded, verbose=0)[0][0])
    print(f"🔍 Вероятность позитивного текста: {pred*100:.2f}%")
    if pred > 0.5:
        print("Вердикт: Позитивный")
    else:
        print("Вердикт: Негативный")

print("\nВводи текст на АНГЛИЙСКОМ. Введи 'exit' для выхода.")
while True:
    s = input("\nТвой текст: ")
    if s.strip().lower() == "exit":
        print("Выход.")
        break
    try:
        analyze_text(s)
    except Exception as e:
        print("Ошибка при предсказании:", str(e))
