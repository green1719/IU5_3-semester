import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import chi2_contingency
import warnings

warnings.filterwarnings('ignore')

# Загрузка данных
df = pd.read_excel('fake_news_result(2).xlsx', sheet_name='News Analysis')

print(f"Всего записей: {len(df)}")
print(f"Real: {len(df[df['Actual Type'] == 'Real'])}")
print(f"Fake: {len(df[df['Actual Type'] == 'Fake'])}")

# ===== 01. ОПИСАТЕЛЬНАЯ СТАТИСТИКА =====
desc_stats = df[['Fake Probability', 'Sentiment Positivity']].describe()
desc_stats_real = df[df['Actual Type'] == 'Real'][['Fake Probability', 'Sentiment Positivity']].describe()
desc_stats_fake = df[df['Actual Type'] == 'Fake'][['Fake Probability', 'Sentiment Positivity']].describe()

desc_stats_all = pd.concat([
    desc_stats.add_suffix('_All'),
    desc_stats_real.add_suffix('_Real'),
    desc_stats_fake.add_suffix('_Fake')
], axis=1)

desc_stats_all.to_csv('01_descriptive_statistics.csv')
print("✅ 01_descriptive_statistics.csv создан")

# ===== 02. КВАРТИЛИ =====
percentiles_data = {
    'Metric': ['Fake Probability', 'Sentiment Positivity'],
    '25%_All': [
        df['Fake Probability'].quantile(0.25),
        df['Sentiment Positivity'].quantile(0.25)
    ],
    '50%_All': [
        df['Fake Probability'].quantile(0.50),
        df['Sentiment Positivity'].quantile(0.50)
    ],
    '75%_All': [
        df['Fake Probability'].quantile(0.75),
        df['Sentiment Positivity'].quantile(0.75)
    ],
    '25%_Real': [
        df[df['Actual Type'] == 'Real']['Fake Probability'].quantile(0.25),
        df[df['Actual Type'] == 'Real']['Sentiment Positivity'].quantile(0.25)
    ],
    '50%_Real': [
        df[df['Actual Type'] == 'Real']['Fake Probability'].quantile(0.50),
        df[df['Actual Type'] == 'Real']['Sentiment Positivity'].quantile(0.50)
    ],
    '75%_Real': [
        df[df['Actual Type'] == 'Real']['Fake Probability'].quantile(0.75),
        df[df['Actual Type'] == 'Real']['Sentiment Positivity'].quantile(0.75)
    ],
    '25%_Fake': [
        df[df['Actual Type'] == 'Fake']['Fake Probability'].quantile(0.25),
        df[df['Actual Type'] == 'Fake']['Sentiment Positivity'].quantile(0.25)
    ],
    '50%_Fake': [
        df[df['Actual Type'] == 'Fake']['Fake Probability'].quantile(0.50),
        df[df['Actual Type'] == 'Fake']['Sentiment Positivity'].quantile(0.50)
    ],
    '75%_Fake': [
        df[df['Actual Type'] == 'Fake']['Fake Probability'].quantile(0.75),
        df[df['Actual Type'] == 'Fake']['Sentiment Positivity'].quantile(0.75)
    ]
}

percentiles_df = pd.DataFrame(percentiles_data)
percentiles_df.to_csv('02_percentiles.csv', index=False)
print("✅ 02_percentiles.csv создан")

# ===== 03. T-TEST (ГЛАВНАЯ ТАБЛИЦА) =====
real_fake = df[df['Actual Type'] == 'Real']['Fake Probability']
fake_fake = df[df['Actual Type'] == 'Fake']['Fake Probability']
real_sent = df[df['Actual Type'] == 'Real']['Sentiment Positivity']
fake_sent = df[df['Actual Type'] == 'Fake']['Sentiment Positivity']

ttest_fake = stats.ttest_ind(real_fake, fake_fake)
ttest_sent = stats.ttest_ind(real_sent, fake_sent)

ttest_results = pd.DataFrame({
    'Variable': ['Fake Probability', 'Sentiment Positivity'],
    't-statistic': [ttest_fake.statistic, ttest_sent.statistic],
    'p-value': [ttest_fake.pvalue, ttest_sent.pvalue],
    'Real_Mean': [real_fake.mean(), real_sent.mean()],
    'Fake_Mean': [fake_fake.mean(), fake_sent.mean()],
    'Real_Std': [real_fake.std(), real_sent.std()],
    'Fake_Std': [fake_fake.std(), fake_sent.std()]
})

ttest_results.to_csv('03_real_vs_fake_ttest.csv', index=False)
print("✅ 03_real_vs_fake_ttest.csv создан")

# ===== 04. КОРРЕЛЯЦИОННЫЙ АНАЛИЗ =====
correlation = df[['Fake Probability', 'Sentiment Positivity']].corr()
correlation_real = df[df['Actual Type'] == 'Real'][['Fake Probability', 'Sentiment Positivity']].corr()
correlation_fake = df[df['Actual Type'] == 'Fake'][['Fake Probability', 'Sentiment Positivity']].corr()

correlation_df = pd.concat([
    correlation.add_suffix('_All'),
    correlation_real.add_suffix('_Real'),
    correlation_fake.add_suffix('_Fake')
], axis=1)

correlation_df.to_csv('04_correlation_analysis.csv')
print("✅ 04_correlation_analysis.csv создан")


# ===== 05. КАТЕГОРИЗАЦИЯ FAKE PROBABILITY =====
def categorize_fake_prob(x):
    if x <= 0.05:
        return 'Низкая (≤0.05)'
    elif x <= 0.1:
        return 'Средняя (0.05-0.1)'
    else:
        return 'Высокая (>0.1)'


df['Fake_Category'] = df['Fake Probability'].apply(categorize_fake_prob)
fake_cat_counts = df['Fake_Category'].value_counts().reset_index()
fake_cat_counts.columns = ['Fake_Probability_Category', 'Count']
fake_cat_counts['Percentage'] = (fake_cat_counts['Count'] / len(df) * 100).round(2)

fake_cat_counts.to_csv('05_fake_categorization.csv', index=False)
print("✅ 05_fake_categorization.csv создан")


# ===== 06. КАТЕГОРИЗАЦИЯ SENTIMENT =====
def categorize_sentiment(x):
    if x <= 0.1:
        return 'Негативный (≤0.1)'
    elif x <= 0.5:
        return 'Нейтральный (0.1-0.5)'
    else:
        return 'Позитивный (>0.5)'


df['Sentiment_Category'] = df['Sentiment Positivity'].apply(categorize_sentiment)
sent_cat_counts = df['Sentiment_Category'].value_counts().reset_index()
sent_cat_counts.columns = ['Sentiment_Category', 'Count']
sent_cat_counts['Percentage'] = (sent_cat_counts['Count'] / len(df) * 100).round(2)

sent_cat_counts.to_csv('06_sentiment_categorization.csv', index=False)
print("✅ 06_sentiment_categorization.csv создан")

# ===== 07. CHI-SQUARE ТЕСТЫ =====
# Связь между категориями Fake Probability и Actual Type
contingency1 = pd.crosstab(df['Fake_Category'], df['Actual Type'])
chi2_1, p1, dof1, expected1 = chi2_contingency(contingency1)

# Связь между категориями Sentiment и Actual Type
contingency2 = pd.crosstab(df['Sentiment_Category'], df['Actual Type'])
chi2_2, p2, dof2, expected2 = chi2_contingency(contingency2)

chi_square_results = pd.DataFrame({
    'Test': ['Fake_Category vs Actual_Type', 'Sentiment_Category vs Actual_Type'],
    'Chi2': [chi2_1, chi2_2],
    'p-value': [p1, p2],
    'dof': [dof1, dof2]
})

chi_square_results.to_csv('07_chi_square_tests.csv', index=False)
print("✅ 07_chi_square_tests.csv создан")

# ===== 08. КЛАССИФИКАЦИЯ ПО ПОРОГУ =====
thresholds = [0.05, 0.1, 0.15, 0.2]
classification_results = []

for threshold in thresholds:
    df['Predicted_Type'] = df['Fake Probability'].apply(lambda x: 'Fake' if x > threshold else 'Real')

    # Матрица ошибок
    real_as_real = len(df[(df['Actual Type'] == 'Real') & (df['Predicted_Type'] == 'Real')])
    real_as_fake = len(df[(df['Actual Type'] == 'Real') & (df['Predicted_Type'] == 'Fake')])
    fake_as_real = len(df[(df['Actual Type'] == 'Fake') & (df['Predicted_Type'] == 'Real')])
    fake_as_fake = len(df[(df['Actual Type'] == 'Fake') & (df['Predicted_Type'] == 'Fake')])

    # Метрики
    accuracy = (real_as_real + fake_as_fake) / len(df)
    precision = fake_as_fake / (fake_as_fake + real_as_fake) if (fake_as_fake + real_as_fake) > 0 else 0
    recall = fake_as_fake / (fake_as_fake + fake_as_real) if (fake_as_fake + fake_as_real) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    classification_results.append({
        'Threshold': threshold,
        'Accuracy': accuracy,
        'Precision': precision,
        'Recall': recall,
        'F1-Score': f1,
        'True_Real': real_as_real,
        'False_Fake': real_as_fake,
        'False_Real': fake_as_real,
        'True_Fake': fake_as_fake
    })

classification_df = pd.DataFrame(classification_results)
classification_df.to_csv('08_threshold_classification.csv', index=False)
print("✅ 08_threshold_classification.csv создан")

# ===== 09. ТЕСТЫ НА НОРМАЛЬНОСТЬ =====
normality_fake_all = stats.shapiro(df['Fake Probability'])
normality_sent_all = stats.shapiro(df['Sentiment Positivity'])
normality_fake_real = stats.shapiro(df[df['Actual Type'] == 'Real']['Fake Probability'])
normality_sent_real = stats.shapiro(df[df['Actual Type'] == 'Real']['Sentiment Positivity'])
normality_fake_fake = stats.shapiro(df[df['Actual Type'] == 'Fake']['Fake Probability'])
normality_sent_fake = stats.shapiro(df[df['Actual Type'] == 'Fake']['Sentiment Positivity'])

normality_results = pd.DataFrame({
    'Group': ['All', 'All', 'Real', 'Real', 'Fake', 'Fake'],
    'Variable': ['Fake_Probability', 'Sentiment_Positivity', 'Fake_Probability', 'Sentiment_Positivity',
                 'Fake_Probability', 'Sentiment_Positivity'],
    'W-statistic': [
        normality_fake_all.statistic,
        normality_sent_all.statistic,
        normality_fake_real.statistic,
        normality_sent_real.statistic,
        normality_fake_fake.statistic,
        normality_sent_fake.statistic
    ],
    'p-value': [
        normality_fake_all.pvalue,
        normality_sent_all.pvalue,
        normality_fake_real.pvalue,
        normality_sent_real.pvalue,
        normality_fake_fake.pvalue,
        normality_sent_fake.pvalue
    ]
})

normality_results.to_csv('09_normality_tests.csv', index=False)
print("✅ 09_normality_tests.csv создан")

# ===== 10. ВЛИЯНИЕ ТОНАЛЬНОСТИ =====
# Линейная регрессия: Fake Probability от Sentiment Positivity
from sklearn.linear_model import LinearRegression

X = df[['Sentiment Positivity']]
y = df['Fake Probability']

model = LinearRegression()
model.fit(X, y)

sentiment_impact = pd.DataFrame({
    'Coefficient': [model.coef_[0]],
    'Intercept': [model.intercept_],
    'R_squared': [model.score(X, y)],
    'Correlation': [df['Fake Probability'].corr(df['Sentiment Positivity'])]
})

# По группам
corr_real = df[df['Actual Type'] == 'Real']['Fake Probability'].corr(
    df[df['Actual Type'] == 'Real']['Sentiment Positivity'])
corr_fake = df[df['Actual Type'] == 'Fake']['Fake Probability'].corr(
    df[df['Actual Type'] == 'Fake']['Sentiment Positivity'])

sentiment_impact['Correlation_Real'] = corr_real
sentiment_impact['Correlation_Fake'] = corr_fake

sentiment_impact.to_csv('10_sentiment_impact.csv', index=False)
print("✅ 10_sentiment_impact.csv создан")

# ===== 11. КЛЮЧЕВЫЕ МЕТРИКИ =====
key_metrics = pd.DataFrame({
    'Metric': [
        'Total_News_Count',
        'Real_News_Count',
        'Fake_News_Count',
        'Fake_Probability_Mean_All',
        'Fake_Probability_Mean_Real',
        'Fake_Probability_Mean_Fake',
        'Sentiment_Positivity_Mean_All',
        'Sentiment_Positivity_Mean_Real',
        'Sentiment_Positivity_Mean_Fake',
        'Fake_Probability_Std_All',
        'Fake_Probability_Std_Real',
        'Fake_Probability_Std_Fake',
        'Sentiment_Positivity_Std_All',
        'Sentiment_Positivity_Std_Real',
        'Sentiment_Positivity_Std_Fake'
    ],
    'Value': [
        len(df),
        len(df[df['Actual Type'] == 'Real']),
        len(df[df['Actual Type'] == 'Fake']),
        df['Fake Probability'].mean(),
        df[df['Actual Type'] == 'Real']['Fake Probability'].mean(),
        df[df['Actual Type'] == 'Fake']['Fake Probability'].mean(),
        df['Sentiment Positivity'].mean(),
        df[df['Actual Type'] == 'Real']['Sentiment Positivity'].mean(),
        df[df['Actual Type'] == 'Fake']['Sentiment Positivity'].mean(),
        df['Fake Probability'].std(),
        df[df['Actual Type'] == 'Real']['Fake Probability'].std(),
        df[df['Actual Type'] == 'Fake']['Fake Probability'].std(),
        df['Sentiment Positivity'].std(),
        df[df['Actual Type'] == 'Real']['Sentiment Positivity'].std(),
        df[df['Actual Type'] == 'Fake']['Sentiment Positivity'].std()
    ]
})

key_metrics.to_csv('11_key_metrics.csv', index=False)
print("✅ 11_key_metrics.csv создан")

# ===== ГРАФИКИ =====
plt.style.use('default')
fig, axes = plt.subplots(2, 2, figsize=(15, 12))

# 01. Scatter с трендом
axes[0, 0].scatter(df['Sentiment Positivity'], df['Fake Probability'], alpha=0.6, c='blue')
z = np.polyfit(df['Sentiment Positivity'], df['Fake Probability'], 1)
p = np.poly1d(z)
axes[0, 0].plot(df['Sentiment Positivity'], p(df['Sentiment Positivity']), "r--", alpha=0.8)
axes[0, 0].set_xlabel('Sentiment Positivity')
axes[0, 0].set_ylabel('Fake Probability')
axes[0, 0].set_title('01. Scatter Plot с линейным трендом')
axes[0, 0].grid(True, alpha=0.3)

# 02. Гистограмма Fake Probability
axes[0, 1].hist(df['Fake Probability'], bins=30, alpha=0.7, color='red', edgecolor='black')
axes[0, 1].set_xlabel('Fake Probability')
axes[0, 1].set_ylabel('Frequency')
axes[0, 1].set_title('02. Гистограмма Fake Probability')
axes[0, 1].grid(True, alpha=0.3)

# 03. Гистограмма Sentiment Positivity
axes[1, 0].hist(df['Sentiment Positivity'], bins=30, alpha=0.7, color='green', edgecolor='black')
axes[1, 0].set_xlabel('Sentiment Positivity')
axes[1, 0].set_ylabel('Frequency')
axes[1, 0].set_title('03. Гистограмма Sentiment Positivity')
axes[1, 0].grid(True, alpha=0.3)

# 04. Box Plot Fake Probability по типам
df_box = df[['Actual Type', 'Fake Probability', 'Sentiment Positivity']].melt(id_vars=['Actual Type'],
                                                                              value_vars=['Fake Probability',
                                                                                          'Sentiment Positivity'],
                                                                              var_name='Metric', value_name='Value')
sns.boxplot(data=df_box[df_box['Metric'] == 'Fake Probability'], x='Actual Type', y='Value', ax=axes[1, 1])
axes[1, 1].set_title('04. Box Plot Fake Probability по типам новостей')
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('01_04_plots.png', dpi=300, bbox_inches='tight')
plt.close()

# Второй набор графиков
fig, axes = plt.subplots(2, 3, figsize=(18, 12))

# 05. Box Plot Sentiment Positivity по типам
sns.boxplot(data=df_box[df_box['Metric'] == 'Sentiment Positivity'], x='Actual Type', y='Value', ax=axes[0, 0])
axes[0, 0].set_title('05. Box Plot Sentiment Positivity по типам')
axes[0, 0].grid(True, alpha=0.3)

# 06. Bar Plot средних значений
means = df.groupby('Actual Type')[['Fake Probability', 'Sentiment Positivity']].mean()
means.plot(kind='bar', ax=axes[0, 1])
axes[0, 1].set_title('06. Bar Plot средних значений по типам')
axes[0, 1].set_ylabel('Mean Value')
axes[0, 1].grid(True, alpha=0.3)
axes[0, 1].tick_params(axis='x', rotation=45)

# 07. KDE Plot плотности
df[df['Actual Type'] == 'Real']['Fake Probability'].plot(kind='kde', ax=axes[0, 2], label='Real', alpha=0.7)
df[df['Actual Type'] == 'Fake']['Fake Probability'].plot(kind='kde', ax=axes[0, 2], label='Fake', alpha=0.7)
axes[0, 2].set_xlabel('Fake Probability')
axes[0, 2].set_ylabel('Density')
axes[0, 2].set_title('07. KDE Plot Fake Probability')
axes[0, 2].legend()
axes[0, 2].grid(True, alpha=0.3)

# 08. Hexbin Plot 2D плотности
hexbin = axes[1, 0].hexbin(df['Sentiment Positivity'], df['Fake Probability'], gridsize=30, cmap='Blues', alpha=0.7)
axes[1, 0].set_xlabel('Sentiment Positivity')
axes[1, 0].set_ylabel('Fake Probability')
axes[1, 0].set_title('08. Hexbin Plot 2D плотности')
plt.colorbar(hexbin, ax=axes[1, 0])

# 09. CDF Plot кумулятивного распределения
sorted_fake = np.sort(df['Fake Probability'])
cdf = np.arange(1, len(sorted_fake) + 1) / len(sorted_fake)
axes[1, 1].plot(sorted_fake, cdf, marker='.', linestyle='none', alpha=0.5, label='Fake Probability')
sorted_sent = np.sort(df['Sentiment Positivity'])
cdf_sent = np.arange(1, len(sorted_sent) + 1) / len(sorted_sent)
axes[1, 1].plot(sorted_sent, cdf_sent, marker='.', linestyle='none', alpha=0.5, label='Sentiment Positivity')
axes[1, 1].set_xlabel('Value')
axes[1, 1].set_ylabel('CDF')
axes[1, 1].set_title('09. CDF Plot кумулятивного распределения')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3)

# 10. Scatter Plot по типам
colors = {'Real': 'blue', 'Fake': 'red'}
for news_type in df['Actual Type'].unique():
    subset = df[df['Actual Type'] == news_type]
    axes[1, 2].scatter(subset['Sentiment Positivity'], subset['Fake Probability'],
                       alpha=0.6, label=news_type, c=colors[news_type])
axes[1, 2].set_xlabel('Sentiment Positivity')
axes[1, 2].set_ylabel('Fake Probability')
axes[1, 2].set_title('10. Scatter Plot по типам новостей')
axes[1, 2].legend()
axes[1, 2].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('05_10_plots.png', dpi=300, bbox_inches='tight')
plt.close()

print("✅ Все графики созданы (2 PNG файла с 10 графиками)")

# Сводная информация
print("\n=== СВОДНАЯ ИНФОРМАЦИЯ ===")
print(f"Всего обработано новостей: {len(df)}")
print(f"Real новостей: {len(df[df['Actual Type'] == 'Real'])}")
print(f"Fake новостей: {len(df[df['Actual Type'] == 'Fake'])}")
print(f"Средняя Fake Probability: {df['Fake Probability'].mean():.4f}")
print(f"Средняя Sentiment Positivity: {df['Sentiment Positivity'].mean():.4f}")