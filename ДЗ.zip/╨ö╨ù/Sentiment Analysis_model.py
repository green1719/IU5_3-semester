import json
import re
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense

# Параметры (можно менять)
num_words = 10000
max_len = 200
epochs = 5
batch_size = 128

model_filename = "models/sentiment_lstm.h5"
meta_filename = "models/sentiment_meta.json"

# Загружаем IMDB (только num_words самых частых токенов)
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.imdb.load_data(num_words=num_words)

# Паддинг
x_train = pad_sequences(x_train, maxlen=max_len)
x_test = pad_sequences(x_test, maxlen=max_len)

# Создаём модель
model = Sequential([
    Embedding(input_dim=num_words, output_dim=128),
    LSTM(128),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy', tf.keras.metrics.AUC(name="auc")])

print("\nНачинаю обучение модели...")
model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2, verbose=1)

loss, acc, auc = model.evaluate(x_test, y_test, verbose=0)
print(f"\nТочность на тесте: {acc * 100:.2f}%")
print(f"AUC на тесте: {auc:.3f}")

# Сохраняем модель
print(f"\nСохраняю модель в '{model_filename}' ...")
model.save(model_filename)

# Сохраняем вспомогательные метаданные
print(f"Сохраняю метаданные в '{meta_filename}' ...")
word_index = tf.keras.datasets.imdb.get_word_index()

with open(meta_filename, "w", encoding="utf-8") as f:
    json.dump({"num_words": num_words, "max_len": max_len, "word_index": word_index}, f)

print("\n✅ Готово. Запусти interface.py для проверки текста.")
