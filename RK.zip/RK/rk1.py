class Computer:
    def __init__(self, id, model, price, display_class_id):
        self.id = id
        self.model = model
        self.price = price
        self.display_class_id = display_class_id


class DisplayClass:
    def __init__(self, id, name):
        self.id = id
        self.name = name


class ComputerDisplayClass:
    def __init__(self, display_class_id, computer_id):
        self.display_class_id = display_class_id
        self.computer_id = computer_id


# Данные
display_classes = [
    DisplayClass(1, "отдел игровых компьютеров"),
    DisplayClass(2, "отдел офисных компьютеров"),
    DisplayClass(3, "учебный класс"),
    DisplayClass(4, "графический отдел"),
    DisplayClass(5, "кафе работников"),
]

computers = [
    Computer(1, "ASUS ROG Strix G15", 150000, 1),
    Computer(2, "Dell OptiPlex 3090", 45000, 2),
    Computer(3, "HP EliteBook 840", 85000, 2),
    Computer(4, "MacBook Pro M2", 210000, 4),
    Computer(5, "Lenovo ThinkPad T490", 65000, 2),
    Computer(6, "MSI Gaming GE76", 180000, 1),
    Computer(7, "Acer Aspire 5", 35000, 3),
    Computer(8, "iMac 27", 195000, 4),
    Computer(9, "Asus VivoBook", 55000, 3),
]

comp_display_classes = [
    ComputerDisplayClass(1, 1),
    ComputerDisplayClass(1, 6),
    ComputerDisplayClass(2, 2),
    ComputerDisplayClass(2, 3),
    ComputerDisplayClass(2, 5),
    ComputerDisplayClass(3, 7),
    ComputerDisplayClass(3, 9),
    ComputerDisplayClass(4, 4),
    ComputerDisplayClass(4, 8),
]

def finder_for_model(any_list):
    result = dict()
    for model, dc_name in any_list:
        model_first_word = model.split()[0]
        if model_first_word[0].upper() == 'A':
            result[model] = dc_name
    return result

def filters(item):
    return len(item[0].split()[0])


def main():
    one_to_many = [
        (c.model, c.price, dc.name)
        for dc in display_classes
        for c in computers
        if c.display_class_id == dc.id
    ]

    many_to_many_temp = [
        (dc.name, cdc.display_class_id, cdc.computer_id)
        for dc in display_classes
        for cdc in comp_display_classes
        if dc.id == cdc.display_class_id
    ]

    many_to_many = [
        (c.model, c.price, dc_name)
        for dc_name, dc_id, c_id in many_to_many_temp
        for c in computers
        if c.id == c_id
    ]

    print("Е1")
    print("Выведите список всех дисплейных классов, у которых в названии присутствует слово 'отдел', и список работающих в них компьютеров.")
    res_e1 = {}

    for dc in display_classes:
        if "отдел" in dc.name:
            dc_computers = [x for x, _, dc_name in one_to_many if dc_name == dc.name]
            res_e1[dc.name] = dc_computers

    print("\nРезультат:")
    for dc_name, comp_models in res_e1.items():
        print(f"{dc_name}:")
        for model in comp_models:
            print(f"  - {model}")

    print("Е2")
    print("Выведите список дисплейных классов со средней ценой компьютеров в каждом классе, отсортированный по средней цене.")
    print("Средняя цена должна быть округлена до 2 знаков после запятой.")

    res_e2 = []
    for dc in display_classes:
        dc_computers = [price for _, price, dc_name in one_to_many if dc_name == dc.name]
        if dc_computers:
            avg = round(sum(dc_computers) / len(dc_computers), 2)
            res_e2.append((dc.name, avg))

    sc_class = sorted(res_e2, key=lambda x: x[1])
    print("\nРезультат (отсортировано по средней цене):")
    for dc_name, avg_price in sc_class:
        print(f"  {dc_name}: {avg_price} ед.")

    print("Е3")
    print("Выведите список всех компьютеров, у которых модель начинается с буквы 'А', и названия их дисплейных классов.")

    many_to_many_for_filter = [(model, dc_name) for (model, _, dc_name) in many_to_many]
    model_result = finder_for_model(many_to_many_for_filter)
    model_list = sorted(list(model_result.items()), key=filters)

    print("\nРезультат:")
    for model, dc_name in model_list:
        print(f"  {model} -> {dc_name}")

if __name__ == "__main__":
    main()
