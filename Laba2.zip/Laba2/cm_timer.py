import time
from contextlib import contextmanager

class cm_timer_1:
    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = time.time()
        print("time:", round(end_time - self.start_time, 6))

@contextmanager
def cm_timer_2():
    start_time = time.time()
    try:
        yield
    finally:
        end_time = time.time()
        print("time:", round(end_time - start_time, 6))


if __name__ == "__main__":
    from time import sleep

    print("cm_timer_1:")
    with cm_timer_1():
        sleep(5.5)

    print("cm_timer_2:")
    with cm_timer_2():
        sleep(5.5)
