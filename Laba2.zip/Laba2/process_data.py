import json
import sys
import random
import time
from contextlib import contextmanager

def print_result(func):
    def buffer(*args, **kwargs):
        result = func(*args, **kwargs)
        if isinstance(result, list):
            print("\n".join(map(str, result)))
        elif isinstance(result, dict):
            for k, v in result.items():
                print(f"{k} = {v}")
        else:
            print(result)
        return result
    return buffer

path = "/Users/ruslangadziev/PycharmProjects/IU5/Laba2/data_light.json"

with open(path) as f:
    data = json.load(f)

@print_result
def f1(arg):
    return sorted({vac["job-name"].strip() for vac in arg}, key=str.lower)


@print_result
def f2(arg):
    return list(filter(lambda x: x.lower().startswith("программист"), arg))

@print_result
def f3(arg):
    return list(map(lambda x: x + " с опытом работы на Python", arg))

@print_result
def f4(arg):
    salaries = [random.randint(100_000, 200_000) for _ in arg]
    return [f"{prof}, зарплата {salary} руб." for prof, salary in zip(arg, salaries)]

@contextmanager
def cm_timer():
    start_time = time.time()
    try:
        yield
    finally:
        end_time = time.time()
        print("time:", round(end_time - start_time, 6))


if __name__ == '__main__':
    with cm_timer():
        f4(f3(f2(f1(data))))