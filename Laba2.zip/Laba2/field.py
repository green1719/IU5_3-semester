goods = [
    {
        'title': 'Ковер "Восточная сказка"',
        'price': 2000,
        'color': 'green',
        'category': 'Декор и текстиль',
        'material': 'шерсть',
        'size': '200x300 см',
        'brand': 'OrientalStyle',
        'rating': 4.7,
        'in_stock': True,
        'discount': 15,
        'weight': 8.5,
        'country': 'Турция',
        'warranty': 2,
        'description': 'Ручная работа с традиционным орнаментом',
        'tags': ['ковер', 'декор', 'премиум', 'ручная работа']
    },
    {
        'title': 'Диван для отдыха "Комфорт Плюс"',
        'color': 'black',
        'price': 45000,
        'category': 'Мебель',
        'material': 'экокожа, металл',
        'size': '220x90x85 см',
        'brand': 'ComfortHome',
        'rating': 4.9,
        'in_stock': False,
        'expected_delivery': '2024-03-15',
        'weight': 85.0,
        'country': 'Россия',
        'warranty': 5,
        'features': ['раскладной', 'оргопора', 'ящик для белья'],
        'description': 'Эргономичный диван с ортопедическим матрасом'
    },
    {
        'title': 'Смартфон Galaxy Ultra',
        'price': 89990,
        'color': 'cosmic silver',
        'category': 'Электроника',
        'brand': 'Samsung',
        'storage': '512 ГБ',
        'ram': '12 ГБ',
        'screen': '6.8" AMOLED',
        'camera': '200 МП',
        'battery': '5000 мАч',
        'os': 'Android 14',
        'rating': 4.8,
        'in_stock': True,
        'discount': 10,
        'warranty': 2,
        'features': ['5G', 'IP68', 'wireless charging']
    },
    {
        'title': 'Кофемашина Deluxe',
        'price': 34990,
        'color': 'stainless steel',
        'category': 'Бытовая техника',
        'brand': 'DeLonghi',
        'power': '1450 Вт',
        'water_tank': '1.8 л',
        'bean_capacity': '250 г',
        'dimensions': '34x24x43 см',
        'rating': 4.6,
        'in_stock': True,
        'weight': 9.2,
        'warranty': 3,
        'features': ['автоматическая очистка', '12 программ', 'пенка']
    },
    {
        'title': 'Беговая дорожка ProFit',
        'price': 125000,
        'color': 'black-red',
        'category': 'Спорт и фитнес',
        'brand': 'ProSport',
        'max_speed': '20 км/ч',
        'max_weight': '150 кг',
        'display': '10.1" touchscreen',
        'programs': 12,
        'rating': 4.5,
        'in_stock': True,
        'weight': 95.0,
        'assembly_required': True,
        'warranty': 2
    }
]
def field(items, *args):
    assert len(args) > 0
    result = []
    for item in items:
        for arg in args:
            try:
                print(item[arg], end="  ")
            except:
                print("отсутвует", end="  ")
                pass
        print()

field(goods, 'title', 'weight')